let text = `<div id=\"topbar\"><link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\" />
<a href="main.html"><img align=left style="margin-right:5px;padding:0px;height:50px;width:200px;"
src="https://raw.githubusercontent.com/WizzardSK/gameflix/master/art/logos/${location.pathname.split('/').pop().replace(/\.html?$/, '')}.svg"></a>
<input type=\"text\" id=\"filterInput\" placeholder=\"Filter...\">
<input type=\"radio\" name=\"thumbtype\" id=\"Snaps\" value=\"Snaps\" checked onclick=\"processImages('snaps')\"><label for=\"Snaps\">Snaps</label>
<input type=\"radio\" name=\"thumbtype\" id=\"Titles\" value=\"Titles\" onclick=\"processImages('titles')\"><label for=\"Titles\">Titles</label>
<input type=\"radio\" name=\"thumbtype\" id=\"Boxarts\" value=\"Boxarts\" onclick=\"processImages('boxarts')\"><label for=\"Boxarts\">Boxarts</label>
<input type=\"radio\" name=\"thumbtype\" id=\"Logos\" value=\"Logos\" onclick=\"processImages('logos')\"><label for=\"Logos\">Logos</label>
<input type=\"radio\" name=\"size\" id=\"80px\" value=\"80px\" onclick=\"changeSize(80)\"><label for=\"80px\">80px</label>
<input type=\"radio\" name=\"size\" id=\"120px\" value=\"120px\" onclick=\"changeSize(120)\"><label for=\"120px\">120px</label>
<input type=\"radio\" name=\"size\" id=\"160px\" value=\"160px\" onclick=\"changeSize(160)\" checked><label for=\"160px\">160px</label>
<input type=\"radio\" name=\"size\" id=\"240px\" value=\"240px\" onclick=\"changeSize(240)\"><label for=\"240px\">240px</label>
<input type=\"radio\" name=\"size\" id=\"320px\" value=\"320px\" onclick=\"changeSize(320)\"><label for=\"320px\">320px</label>
<br />
<span id=\"pocet\"></span>
<input type=\"checkbox\" id=\"showHideProto\" checked><label for=\"showHideProto\">Proto</label>
<input type=\"checkbox\" id=\"showHideProgram\" checked><label for=\"showHideProgram\">Program</label>
<input type=\"checkbox\" id=\"showHideAlfa\"><label for=\"showHideAlfa\">Alpha</label>
<input type=\"checkbox\" id=\"showHideBeta\"><label for=\"showHideBeta\">Beta</label>
<input type=\"checkbox\" id=\"showHidePrerelease\"><label for=\"showHidePrerelease\">Pre</label>
<input type=\"checkbox\" id=\"showHideDemo\"><label for=\"showHideDemo\">Demo</label>
<input type=\"checkbox\" id=\"showHideAftermarket\"><label for=\"showHideAftermarket\">After</label>
<input type=\"checkbox\" id=\"showHideUnl\"><label for=\"showHideUnl\">Unl</label>
<input type=\"checkbox\" id=\"showHideAlt\"><label for=\"showHideAlt\">Alt</label>
<input type=\"checkbox\" id=\"showHidePirate\"><label for=\"showHidePirate\">Pirate</label>
<input type=\"checkbox\" id=\"showHideBrackets\"><label for=\"showHideBrackets\">[a][b]</label>
<input type=\"checkbox\" id=\"showHideDisk\"><label for=\"showHideDisk\">[disk2]</label>
<div id="navlinks"></div></div>`;

document.write(text);

// On Android, launch games in the native RetroArch app (intent://). No-op elsewhere.
document.write('<script src="intent.js"></script>');

var _bgPlatform;
function bgImage(platform) {
    if (_bgPlatform !== platform) {
        _bgPlatform = platform;
        document.write(`<style> figure { background-image: url('https://raw.githubusercontent.com/WizzardSK/gameflix/master/art/consoles/${platform}.png'); } </style>`);
    }
}

// TIC-80 carts are played locally, in tic80_libretro, not on tic80.com: the
// site sends X-Frame-Options: SAMEORIGIN, so its player can never load in the
// "main" frame gameflix is built out of. The cart itself is fetched straight
// from tic80.com, which serves /cart/<hash>/<anything>.tic - so the play://
// path carries the hash as its folder and the cart's own file name as the ROM,
// and launch.tsv maps /TIC-80/ to https://tic80.com/cart/.
function generateTicLinks(romPath, imagePath) {
    var headers = document.querySelectorAll('.section-header');
    var foldername = headers.length ? headers[headers.length - 1].id : '';
    var base = encodeURI('play:///TIC-80/' + foldername);
    var html = [];
    fileNames.forEach(fileName => {
        var [id, hash, nazov, subor] = fileName.split('\t');
        // RetroArch picks the core by extension, and tic80.com has carts whose
        // file name carries none, so the name is only ever a label here - the
        // hash in the path is what identifies the cart.
        var rom = subor || hash;
        if (!/\.tic$/i.test(rom)) rom += '.tic';
        var href = `${base}/${hash}/${encodeURIComponent(rom)}`;
        html.push(`<a href="${href}" target="main" rel="noreferrer">
        <figure><img loading="lazy" src="https://tic80.com/cart/${hash}/cover.gif" alt="${nazov}"><figcaption>${nazov}</figcaption></figure></a>`);
    });
    document.write('<div class="figureList">' + html.join('') + '</div>');
}

function generateWasmLinks(romPath, imagePath) {
    romPath = romPath.replace("roms/WASM-4", "https://wasm4.org/play");
    var html = [];
    fileNames.forEach(fileName => {
        var [subor, nazov] = fileName.split('\t');
        html.push(`<a href="${romPath}/${encodeURIComponent(subor)}" target="main">
        <figure><img loading="lazy" src="https://wasm4.org/carts/${subor}.png" alt="${nazov}"><figcaption>${nazov}</figcaption></figure></a>`);
    });
    document.write('<div class="figureList">' + html.join('') + '</div>');
}

function generateLrNXLinks(romPath, imagePath) {
    romPath = romPath.replace("roms/LowresNX", "https://lowresnx.inutilis.com/topic.php?id=");
    var html = [];
    fileNames.forEach(fileName => {
        var [subor, obrazok, nazov, id] = fileName.split('\t');
        html.push(`<a href="${romPath}${encodeURIComponent(id)}" target="main">
        <figure><img loading="lazy" src="https://lowresnx.inutilis.com/uploads/${obrazok}" alt="${nazov}"><figcaption>${nazov}</figcaption></figure></a>`);
    });
    document.write('<div class="figureList">' + html.join('') + '</div>');
}

function generatePicoLinks(romPath, imagePath) {
    var html = [];
    fileNames.forEach(fileName => {
        var [id, nazov, kart] = fileName.split('\t');
        var screen = /^\d/.test(kart) ? "pico" + kart.replace(/\.p8\.png$/, '.png') : kart.replace(/^(.*)\.p8\.png$/, 'pico8_$1.png');
        var cart = kart.replace(/\.p8.png$/, "");
        html.push(`<a href="https://www.lexaloffle.com/bbs/?pid=${cart}#p" target="main">
        <figure><img loading="lazy" src="https://www.lexaloffle.com/bbs/thumbs/${screen}" alt="${nazov}"><figcaption>${nazov}</figcaption></figure></a>`);
    });
    document.write('<div class="figureList">' + html.join('') + '</div>');
}

function generateVoxLinks(romPath, imagePath) {
    var html = [];
    fileNames.forEach(fileName => {
        var [id, nazov, kart] = fileName.split('\t');
        var screen = kart.replace(/^(.*)\.vx\.png$/, 'vox_$1.png').replace(/^cpost/, "vox");
        var cart = kart.replace(/^cpost/, "").replace(/\.png$/, "");
        html.push(`<a href="https://www.lexaloffle.com/bbs/?pid=${cart}#p" target="main">
        <figure><img loading="lazy" src="https://www.lexaloffle.com/bbs/thumbs/${screen}" alt="${nazov}"><figcaption>${nazov}</figcaption></figure></a>`);
    });
    document.write('<div class="figureList">' + html.join('') + '</div>');
}

function generateFileLinks(romPath, imagePath) {
    var wrapInJavatari = false;
    var platform = location.pathname.split('/').pop().replace(/\.html?$/, '');
    var headers = document.querySelectorAll('.section-header');
    var foldername = headers.length ? headers[headers.length - 1].id : '';
    romPath = 'play:///' + platform + '/' + foldername;
    var encodedPath = encodeURI(romPath);
    var html = [];
    fileNames.forEach(fileName => {
        var subor = fileName.includes("\t") ? fileName.split("\t")[0] : fileName;
        var nameWithoutExt = subor.includes(".") ? subor.slice(0, subor.lastIndexOf(".")) : subor;
        var nameWithoutBrackets = nameWithoutExt.replace(/^([^)]*\([^)]*\)).*$/, "$1");
        var nazov = fileName.includes("\t") ? fileName.split("\t")[1] : fileName.replace(/\.[^.]+$/, "");
        var fileUrl = `${encodedPath}/${encodeURIComponent(subor)}`;
        var href = wrapInJavatari ? `https://javatari.org/?rom=${encodeURIComponent(fileUrl)}` : fileUrl;
        html.push(`<a href="${href}" target="main" rel="noreferrer">
        <figure><img loading="lazy" src="https://raw.githubusercontent.com/WizzardSK/${imagePath}/master/Named_Snaps/${encodeURIComponent(nameWithoutBrackets)}.png" alt="${nameWithoutExt}"><figcaption>${nazov}</figcaption></figure></a>`);
    });
    document.write('<div class="figureList">' + html.join('') + '</div>');
}
