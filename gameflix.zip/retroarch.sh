#!/bin/bash
head "$1"
adresar=$(dirname "$1")
adresar2="${adresar##*/}"
case "$adresar/" in
*"TIC-80/"*) core="tic80_libretro";;
*"LowresNX/"*) core="lowresnx_libretro";;
*"WASM-4/"*) core="wasm4_libretro";;
*"PICO-8/"*) core="pico8 -run";;
*"Voxatron/"*) core="vox";;
*"Miscellaneous/Atari Mania/Atari-2600-VCS-ROM-Collection/ROMS/"*) core="stella_libretro";;
*"No-Intro/Atari - Atari 2600/"*) core="stella_libretro";;
*"TOSEC/Atari/2600 & VCS/Games/"*) core="stella_libretro";;
*"TOSEC/Atari/2600 & VCS/Homebrew/Games/[BIN]/"*) core="stella_libretro";;
*"TOSEC/Atari/2600 & VCS/Applications/"*) core="stella_libretro";;
*"TOSEC/Atari/2600 & VCS/Educational/"*) core="stella_libretro";;
*"MAME/Software List ROMs (merged)/a2600/"*) core="stella_libretro";;
*"MAME/Software List ROMs (split)/a2600/"*) core="stella_libretro";;
*"No-Intro/Atari - Atari 5200/"*) core="a5200_libretro";;
*"TOSEC/Atari/5200/Games/"*) core="a5200_libretro";;
*"TOSEC/Atari/5200/Homebrew/Games/"*) core="a5200_libretro";;
*"TOSEC/Atari/5200/Applications/"*) core="a5200_libretro";;
*"MAME/Software List ROMs (merged)/a5200/"*) core="a5200_libretro";;
*"MAME/Software List ROMs (split)/a5200/"*) core="a5200_libretro";;
*"No-Intro/Atari - Atari 7800 (BIN)/"*) core="prosystem_libretro";;
*"TOSEC/Atari/7800/Games/"*) core="prosystem_libretro";;
*"TOSEC/Atari/7800/Homebrew/Games/"*) core="prosystem_libretro";;
*"TOSEC/Atari/7800/Applications/"*) core="prosystem_libretro";;
*"MAME/Software List ROMs (merged)/a7800/"*) core="prosystem_libretro";;
*"MAME/Software List ROMs (split)/a7800/"*) core="prosystem_libretro";;
esac

if [ -n "$ext" ]; then
  umount -l ~/iso; mount-zip "$1" ~/iso
  rom=$(find ~/iso -type f -name "*.${ext}" | head -n 1)
else
  rom="$1"
fi

if [[ "$1" == *"/ti99_cart/"* ]]; then rom="$(basename "${1%.*}")"; fi

if [[ "$core" == *"mame"* ]]; then
  filename="${rom##*/}"; basename="${filename%.*}"
  ${core} "${rom}" -skip_gameinfo -snapname "${basename}"
  exit
fi

if [[ "$core" == *"libretro"* ]]; then
  retroarch -L ~/.config/retroarch/cores/${core}.so "${rom}"
else
  ${core} "${rom}"
fi

if [ -z "$core" ]; then
  ark "$1"
fi
