#!/bin/bash
head "$1"
adresar=$(dirname "$1")
adresar2="${adresar##*/}"
case "$adresar" in
*"TIC-80") core="tic80_libretro";;
*"WASM-4") core="wasm4_libretro";;
*"Uzebox") core="uzem_libretro";;
*"LowresNX") core="lowresnx_libretro";;
*"PICO-8") core="pico8 -run";;
*"Voxatron") core="vox";;
*"Vircon32") core="vircon32_libretro";;
*"Atari 2600 ROMS") core="stella_libretro";;
*"") core="stella_libretro";;
*"") core="stella_libretro";;
*"") core="stella_libretro";;
*"") core="a5200_libretro";;
*"") core="a5200_libretro";;
*"") core="prosystem_libretro";;
*"") core="prosystem_libretro";;
*"") core="atari800";;
*"") core="atari800";;
*"") core="atari800";;
*"") core="atari800";;
*"") core="atari800";;
*"") core="atari800";;
*"") core="atari800";;
*"") core="atari800";;
*"") core="hatari_libretro";;
*"") core="hatari_libretro";;
*"") core="hatari_libretro";;
*"") core="hatari_libretro";;
*"") core="hatari_libretro";;
*"") core="virtualjaguar_libretro";;
*"") core="virtualjaguar_libretro";;
*"") core="bigpemu"; ext="cue";;
*"") core="bigpemu"; ext="cdi";;
*"") core="mednafen_lynx_libretro";;
*"") core="mednafen_lynx_libretro";;
*"") core="freechaf_libretro";;
*"") core="freechaf_libretro";;
*"") core="vecx_libretro";;
*"") core="vecx_libretro";;
*"") core="o2em_libretro";;
*"") core="o2em_libretro";;
*"") core="o2em_libretro";;
*"") core="o2em_libretro";;
*"") core="freeintv_libretro";;
*"") core="freeintv_libretro";;
*"") core="mame adam -flop1";;
*"") core="bluemsx_libretro";;
*"") core="bluemsx_libretro";;
*"") core="emuscv_libretro";;
*"") core="emuscv_libretro";;
*"") core="mame gamepock -cart";;
*"") core="potator_libretro";;
*"") core="potator_libretro";;
*"") core="mednafen_wswan_libretro";;
*"") core="mednafen_wswan_libretro";;
*"") core="mednafen_wswan_libretro";;
*"") core="mednafen_wswan_libretro";;
*"") core="mednafen_wswan_libretro";;
*"") core="arduous_libretro";;
*"") core="arduous_libretro";;
*"") core="mame megaduck -cart";;
*"") core="mame gamate -cart";;
*"") core="mame gamate -cart";;
*"") core="mame gmaster -cart";;
*"") core="mame gmaster -cart";;
*"") core="mame gamecom -cart1";;
*"") core="mame gamecom -cart1";;
*"") core="mame gp32 -memc";;
*"") core="mame gp32 -memc";;
*"") core="cap32_libretro";;
*"") core="cap32_libretro";;
*"") core="cap32_libretro";;
*"") core="cap32_libretro";;
*"") core="81_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="fuse_libretro";;
*"") core="bluemsx_libretro";;
*"") core="simcoupe";;
*"") core="simcoupe";;
*"") core="clksignal --quickload";;
*"") core="clksignal --quickload";;
*"") core="mame astrocde -cart";;
*"") core="mame astrocde -cart";;
*"") core="mame apfm1000 -cart";;
*"") core="mame apfm1000 -cart";;
*"") core="mame advision -cart";;
*"") core="mame advision -cart";;
*"") core="mame crvision -cart";;
*"") core="mame crvision -cart";;
*"") core="mame vsmile -cart";;
*"") core="mame vsmile -cart";;
*"") core="mame arcadia -cart";;
*"") core="mame arcadia -cart";;
*"") core="mame pv1000 -cart";;
*"") core="mame pv1000 -cart";;
*"") core="mame supracan -cart";;
*"") core="mame supracan -cart";;
*"") core="mame vc4000 -cart";;
*"") core="gearsystem_libretro";;
*"") core="mame coco3 -cart";;
*"") core="mame vis -cdrm"; ext="cue";;
*"") core="mame bbcb -flop1";;
*"") core="mame electron64 -cass";;
*"") core="mame aa4401 -flop";;
*"") core="mame fm7 -flop1";;
*"") core="mame fm7 -flop1";;
*"") core="mame fmtmarty -cdrm";;
*"") core="mame tutor -cart";;
*"") core="mame apple2ee -flop1";;
*"") core="mame apple2ee -flop1";;
*"") core="mame apple2ee -flop1";;
*"") core="mame apple2ee -flop1";;
*"") core="mame apple2ee -flop1";;
*"") core="mame apple2ee -flop1";;
*"") core="theodore_libretro";;
*"") core="theodore_libretro";;
*"") core="theodore_libretro";;
*"") core="theodore_libretro";;
*"") core="theodore_libretro";;
*"") core="theodore_libretro";;
*"") core="theodore_libretro";;
*"") core="nestopia_libretro";;
*"") core="nestopia_libretro";;
*"") core="nestopia_libretro";;
*"") core="nestopia_libretro";;
*"") core="snes9x_libretro";;
*"") core="snes9x_libretro";;
*"") core="snes9x_libretro";;
*"") core="snes9x_libretro";;
*"") core="snes9x_libretro";;
*"") core="mupen64plus_next_libretro";;
*"") core="mupen64plus_next_libretro";;
*"") core="dolphin_libretro"; ext="rvz";;
*"") core="dolphin_libretro"; ext="iso";;
*"") core="dolphin_libretro"; ext="wad";;
*"") core="dolphin_libretro"; ext="rvz";;
*"") core="cemu -g"; ext="wux";;
*"") core="pokemini_libretro";;
*"") core="pokemini_libretro";;
*"") core="mednafen_vb_libretro";;
*"") core="mednafen_vb_libretro";;
*"") core="sameboy_libretro";;
*"") core="sameboy_libretro";;
*"") core="sameboy_libretro";;
*"") core="sameboy_libretro";;
*"") core="mgba_libretro";;
*"") core="sameboy_libretro";;
*"") core="melonds_libretro";;
*"") core="melonds_libretro";;
*"") core="melonds_libretro";;
*"") core="melondsds_libretro";;
*"") core="citra_libretro"; ext="3ds";;
*"") core="genesis_plus_gx_libretro";;
*"") core="genesis_plus_gx_libretro";;
*"") core="genesis_plus_gx_libretro";;
*"") core="genesis_plus_gx_libretro";;
*"") core="genesis_plus_gx_libretro";;
*"") core="genesis_plus_gx_libretro";;
*"") core="picodrive_libretro";;
*"") core="picodrive_libretro";;
*"") core="picodrive_libretro";;
*"") core="picodrive_libretro";;
*"") core="picodrive_libretro"; ext="cue";;
*"") core="picodrive_libretro"; ext="cue";;
*"") core="yabasanshiro_libretro"; ext="cue";;
*"") core="yabasanshiro_libretro"; ext="cue";;
*"") core="yabasanshiro_libretro"; ext="cue";;
*"") core="flycast_libretro"; ext="cue";;
*"") core="flycast_libretro"; ext="gdi";;
*"") core="flycast_libretro"; ext="gdi";;
*"") core="flycast_libretro"; ext="gdi";;
*"") core="flycast_libretro"; ext="gdi";;
*"") core="genesis_plus_gx_libretro";;
*"") core="genesis_plus_gx_libretro";;
*"") core="pcsx_rearmed_libretro"; ext="cue";;
*"") core="pcsx_rearmed_libretro"; ext="cue";;
*"") core="pcsx2"; ext="iso";;
*"") core="pcsx2"; ext="iso";;
*"") core="ppsspp_libretro"; ext="iso";;
*"") core="ppsspp_libretro"; ext="iso";;
*"") core="ppsspp_libretro"; ext="iso";;
*"") core="ppsspp_libretro"; ext="iso";;
*"") core="mednafen_pce_fast_libretro";;
*"") core="mednafen_pce_fast_libretro";;
*"") core="mednafen_pce_fast_libretro"; ext="cue";;
*"") core="mednafen_pce_fast_libretro"; ext="cue";;
*"") core="mednafen_supergrafx_libretro";;
*"") core="mednafen_supergrafx_libretro";;
*"") core="mednafen_pcfx_libretro"; ext="cue";;
*"") core="mednafen_pcfx_libretro"; ext="cue";;
*"") core="same_cdi_libretro"; ext="cue";;
*"") core="same_cdi_libretro"; ext="cue";;
*"") core="same_cdi_libretro"; ext="cue";;
*"") core="opera_libretro"; ext="cue";;
*"") core="opera_libretro"; ext="cue";;
*"") core="opera_libretro"; ext="cue";;
*"roms/MS-DOS eXoDOS") core="dosbox_pure_libretro";;
*"roms/MS-DOS eXoDOS") core="dosbox_pure_libretro";;
*"roms/MS-DOS eXoDOS") core="dosbox_pure_libretro";;
*"roms/TDC") core="dosbox_pure_libretro";;
*"roms/TDC") core="bluemsx_libretro";;
*"roms/TDC") core="bluemsx_libretro";;
*"roms/TDC") core="bluemsx_libretro";;
*"roms/TDC") core="bluemsx_libretro";;
*"roms/TDC") core="bluemsx_libretro";;
*"roms/TDC") core="bluemsx_libretro";;
*"roms/TDC") core="vice_xpet_libretro";;
*"roms/TDC") core="vice_xplus4_libretro";;
*"roms/TDC") core="vice_xplus4_libretro";;
*"roms/TDC") core="vice_xplus4_libretro";;
*"roms/TDC") core="vice_xvic_libretro";;
*"roms/TDC") core="vice_xvic_libretro";;
*"roms/TDC") core="vice_xvic_libretro";;
*"roms/TDC") core="vice_xvic_libretro";;
*"roms/TDC") core="vice_xvic_libretro";;
*"roms/TDC") core="vice_x128_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="vice_x64sc_libretro";;
*"roms/TDC") core="puae_libretro";;
*"roms/TDC") core="puae_libretro";;
*"roms/TDC") core="puae_libretro";;
*"roms/TDC") core="puae_libretro";;
*"roms/TDC") core="puae_libretro";;
*"roms/TDC") core="puae_libretro";;
*"roms/TDC") core="puae_libretro";;
*"roms/TDC") core="puae_libretro"; ext="cue";;
*"roms/TDC") core="puae_libretro"; ext="cue";;
*"roms/TDC") core="puae_libretro"; ext="cue";;
*"roms/TDC") core="puae_libretro"; ext="cue";;
*"roms/TDC") core="quasi88_libretro";;
*"roms/TDC") core="np2kai_libretro";;
*"roms/TDC") core="x1_libretro";;
*"roms/TDC") core="x1_libretro";;
*"roms/TDC") core="px68k_libretro";;
*"roms/TDC") core="mame";;
*"roms/TDC") core="fbneo_libretro";;
*"roms/TDC") core="supermodel";;
*"roms/TDC") core="neocd_libretro"; ext="cue";;
*"roms/TDC") core="neocd_libretro"; ext="cue";;
*"roms/TDC") core="mednafen_ngp_libretro";;
*"roms/TDC") core="mednafen_ngp_libretro";;
*"roms/TDC") core="mednafen_ngp_libretro";;
*"roms/TDC") core="mednafen_ngp_libretro";;
*"Neo Geo") core="fbneo_libretro";;
esac

if [ -n "$ext" ]; then
  umount -l ~/iso
  mount-zip "$1" ~/iso
  rom=$(find ~/iso -type f -name "*.${ext}" | head -n 1)
else
  rom="$1"
fi

if [[ "$core" == *"mame"* ]]; then
  filename="${rom##*/}"
  basename="${filename%.*}"
  ${core} "${rom}" -skip_gameinfo -snapname "${basename}"
  exit
fi

if [[ "$core" == *"libretro"* ]]; then
  retroarch -L ~/.config/retroarch/cores/${core}.so "${rom}"
else
  ${core} "${rom}"
fi

if [ -z "$core" ]; then
  ark "$1"
fi
