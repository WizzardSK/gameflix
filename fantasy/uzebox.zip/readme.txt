To build emuze, you will need the Gconvert tool and your path set correctly.

Gconvert available here: http://code.google.com/p/uzebox/downloads/list
For help with Uzebox queries: http://uzebox.org/forums/
